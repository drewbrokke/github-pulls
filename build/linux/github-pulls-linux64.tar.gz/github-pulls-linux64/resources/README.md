##Github Pulls - Linux Instructions

###To Install:
- Unzip the tarball
- Execute the included *install.sh* script with: `sudo ./install.sh`

###Running:
After executing the install script, you can run from the command line with `github-pulls`.
You can also double-click the icon found in `/usr/share/applications`.

###To Uninstall
- Execute the included *uninstall.sh* script with: `sudo ./uninstall.sh`

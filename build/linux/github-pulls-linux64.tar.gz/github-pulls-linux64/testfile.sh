#!/bin/bash

mkdir temp

cd temp

curl https://github.com/drewbrokke/github-pulls/archive/0.1.0.tar.gz

mv 0.1.0.tar.gz /opt


